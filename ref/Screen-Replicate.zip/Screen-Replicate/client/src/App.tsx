import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import StudyManagement from "@/pages/study-management";
import Dashboard from "@/pages/dashboard";
import DataIntegration from "@/pages/data-integration";
import DataManager from "@/pages/data-manager";
import CentralMonitor from "@/pages/central-monitor";
import TrialDataManagement from "@/pages/trial-data-management";
import SignalDetection from "@/pages/signal-detection";
import TasksManagement from "@/pages/tasks-management";

function Router() {
  return (
    <Switch>
      <Route path="/" component={StudyManagement} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/data-integration" component={DataIntegration} />
      <Route path="/data-manager" component={DataManager} />
      <Route path="/central-monitor" component={CentralMonitor} />
      <Route path="/trial-data" component={TrialDataManagement} />
      <Route path="/signal-detection" component={SignalDetection} />
      <Route path="/tasks" component={TasksManagement} />
      {/* AI Agents Hub can route to Data Manager for now as it's the main AI entry point visually */}
      <Route path="/ai-agents" component={DataManager} /> 
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
