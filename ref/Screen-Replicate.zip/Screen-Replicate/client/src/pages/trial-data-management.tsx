import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { 
  FileText, 
  Download, 
  Upload, 
  Filter, 
  RefreshCw, 
  Plus, 
  Edit, 
  Trash2,
  Database,
  Search
} from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function TrialDataManagement() {
  return (
    <Layout>
      <div className="mb-6 flex items-center justify-between">
         <div>
            <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Trial Data Management</h1>
            <p className="text-gray-500 mt-2">View and analyze clinical trial data across multiple sources</p>
         </div>
         <div className="flex gap-2">
            <Button variant="outline" className="gap-2 bg-white">
                <FileText className="h-4 w-4" /> Reports
            </Button>
            <Button variant="outline" className="gap-2 bg-white">
                <Download className="h-4 w-4" /> Export
            </Button>
         </div>
      </div>

      {/* Study Info Card */}
      <Card className="mb-6 border-none shadow-sm bg-white">
          <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                  <div>
                      <h2 className="text-xl font-bold text-gray-900">Diabetes Type 2 Study</h2>
                      <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                          <span>Protocol: PRO001</span>
                          <span>|</span>
                          <span>Phase: Phase 3</span>
                          <span>|</span>
                          <span>Status: <span className="text-green-600 font-medium">Active</span></span>
                      </div>
                  </div>
              </div>
              <div className="grid grid-cols-4 gap-8">
                  <div>
                      <div className="text-xs text-gray-500 uppercase tracking-wide mb-1">Indication</div>
                      <div className="font-semibold text-gray-900">Type 2 Diabetes</div>
                  </div>
                  <div>
                      <div className="text-xs text-gray-500 uppercase tracking-wide mb-1">Start Date</div>
                      <div className="font-semibold text-gray-900">1/1/2023</div>
                  </div>
                  <div>
                      <div className="text-xs text-gray-500 uppercase tracking-wide mb-1">End Date</div>
                      <div className="font-semibold text-gray-900">1/1/2025</div>
                  </div>
                  <div>
                      <div className="text-xs text-gray-500 uppercase tracking-wide mb-1">Enrolled Patients</div>
                      <div className="font-semibold text-gray-900">N/A</div>
                  </div>
              </div>
          </CardContent>
      </Card>

      {/* Data Source Tabs */}
      <div className="flex gap-1 mb-6 bg-white p-1 rounded-lg border border-gray-200 w-full overflow-x-auto">
          {["EDC Data", "EDC Audit Data", "Lab Data", "Imaging Data", "CTMS Data"].map((tab, i) => (
              <Button key={i} variant={i === 0 ? "secondary" : "ghost"} className={`flex-1 ${i===0 ? "bg-white shadow-sm text-blue-600 font-bold border border-gray-100" : "text-gray-500 hover:text-gray-700"}`}>
                  {tab}
              </Button>
          ))}
      </div>

      {/* Domain Navigation & Data Area */}
      <Card className="border-none shadow-sm bg-white overflow-hidden rounded-xl">
          <CardHeader className="bg-white px-6 py-5 border-b border-gray-100 flex flex-row items-center justify-between">
              <div>
                  <CardTitle className="text-xl font-bold text-gray-800">Electronic Data Capture (EDC)</CardTitle>
                  <div className="flex items-center gap-2 text-sm text-gray-500 mt-1">
                      <span>Data Provider: Oracle Health Sciences</span>
                      <Badge variant="outline" className="bg-blue-50 text-blue-600 border-none">ODM Adapter v1.2</Badge>
                  </div>
              </div>
              <div className="flex items-center gap-2 text-sm text-gray-400">
                  <Database className="h-4 w-4" />
                  Last sync: 9/12/2025
              </div>
          </CardHeader>
          
          <div className="bg-gray-50/50 px-6 py-3 border-b border-gray-100">
             <div className="flex gap-2 overflow-x-auto pb-2">
                 {["DM", "SV", "DS", "AE", "SAE", "MH", "CM", "PD", "VS", "LB", "EX"].map((domain, i) => (
                     <Button key={i} variant="ghost" size="sm" className={`h-8 px-3 font-medium ${domain === "DM" ? "bg-white text-blue-600 shadow-sm" : "text-gray-500 hover:text-gray-900 hover:bg-white"}`}>
                         {domain}
                     </Button>
                 ))}
             </div>
          </div>

          <div className="px-6 py-4">
              <div className="mb-4">
                  <h3 className="text-lg font-bold text-gray-900">Demographics</h3>
                  <p className="text-sm text-gray-500">Subject demographics and baseline characteristics</p>
              </div>

              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                  <div className="flex items-center gap-6">
                      <div className="flex gap-8 text-sm">
                          <div>
                              <span className="text-gray-500 block text-xs uppercase">Data Source:</span>
                              <span className="font-semibold">EDC</span>
                          </div>
                          <div>
                              <span className="text-gray-500 block text-xs uppercase">Domain</span>
                              <span className="font-semibold">DM</span>
                          </div>
                          <div>
                              <span className="text-gray-500 block text-xs uppercase">Records</span>
                              <span className="font-semibold">150</span>
                          </div>
                      </div>
                  </div>
                  
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                      <div className="relative flex-1 sm:w-64">
                          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-400" />
                          <Input placeholder="Search records..." className="pl-9 h-9" />
                      </div>
                      <Button variant="outline" size="sm" className="h-9 gap-2"><Filter className="h-3 w-3" /> Filter</Button>
                      <Button variant="outline" size="sm" className="h-9 gap-2"><Download className="h-3 w-3" /> Export</Button>
                  </div>
              </div>

              <div className="flex items-center justify-between mb-4 bg-gray-50 p-2 rounded-lg border border-gray-100">
                  <Button variant="ghost" size="sm" className="text-gray-500 text-xs">Show All Columns</Button>
                  <div className="flex gap-2">
                       <Button variant="outline" size="sm" className="h-8 gap-2 bg-white text-gray-600 border-gray-200">
                          <RefreshCw className="h-3 w-3" /> Refresh
                       </Button>
                       <Button size="sm" className="h-8 gap-2 bg-blue-600 hover:bg-blue-700">
                          <Plus className="h-3 w-3" /> Add Record
                       </Button>
                  </div>
              </div>
              
              <Table>
                <TableHeader className="bg-gray-50/50">
                  <TableRow className="border-gray-100">
                    <TableHead className="w-[150px] font-semibold text-gray-500 pl-4">Record ID</TableHead>
                    <TableHead className="font-semibold text-gray-500">Data</TableHead>
                    <TableHead className="font-semibold text-gray-500 text-right pr-12">Import Date</TableHead>
                    <TableHead className="text-right font-semibold text-gray-500 pr-4">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  <TableRow className="border-gray-100 hover:bg-gray-50/50">
                    <TableCell className="font-medium text-gray-900 pl-4 align-top py-4">DM-1-19</TableCell>
                    <TableCell className="py-4">
                        <div className="space-y-1 text-sm">
                            <div className="flex gap-2"><span className="font-semibold w-24 text-gray-700">STUDYID:</span> <span className="text-gray-600">PRO001</span></div>
                            <div className="flex gap-2"><span className="font-semibold w-24 text-gray-700">DOMAIN:</span> <span className="text-gray-600">DM</span></div>
                            <div className="flex gap-2"><span className="font-semibold w-24 text-gray-700">USUBJID:</span> <span className="text-gray-600">S-1-019</span></div>
                            <div className="flex gap-2"><span className="font-semibold w-24 text-gray-700">SUBJID:</span> <span className="text-gray-600">019</span></div>
                            <div className="flex gap-2"><span className="font-semibold w-24 text-gray-700">RFSTDTC:</span> <span className="text-gray-600">2025-03-03</span></div>
                        </div>
                    </TableCell>
                    <TableCell className="text-right pr-12 text-gray-600 align-top py-4">23/10/2025</TableCell>
                    <TableCell className="text-right pr-4 align-top py-4">
                        <div className="flex justify-end gap-2">
                             <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-blue-600"><Edit className="h-4 w-4" /></Button>
                             <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-rose-600"><Trash2 className="h-4 w-4" /></Button>
                        </div>
                    </TableCell>
                  </TableRow>
                </TableBody>
              </Table>
          </div>
      </Card>
    </Layout>
  );
}
