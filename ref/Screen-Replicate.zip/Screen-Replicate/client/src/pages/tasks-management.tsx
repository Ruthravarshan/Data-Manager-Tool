import Layout from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  CheckSquare, 
  Plus,
  Download,
  Search,
  Filter,
  User,
  MoreHorizontal
} from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";

export default function TasksManagement() {
  return (
    <Layout>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Query & Task Workflow Management</h1>
          <p className="text-gray-500 mt-2">Manage and track queries and tasks across clinical trials and stakeholders</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-gray-600 bg-white px-3 py-1.5 rounded-lg border border-gray-200 shadow-sm">
             <User className="h-4 w-4 text-gray-400" />
             <div className="flex flex-col text-right leading-tight">
                 <span className="text-[10px] text-gray-400 uppercase">Logged in as</span>
                 <span className="font-semibold">System Administrator</span>
             </div>
          </div>
          <div className="flex gap-2">
             <Button variant="outline" className="gap-2 bg-white">
                <Download className="h-4 w-4" /> Export
             </Button>
             <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2 shadow-sm">
                <Plus className="h-4 w-4" /> New Query
             </Button>
          </div>
        </div>
      </div>

      <div className="flex gap-1 mb-6 bg-white p-1 rounded-lg border border-gray-200 w-fit">
          {["All Queries & Tasks", "Assigned to Me", "Created by Me", "Responded"].map((tab, i) => (
              <Button key={i} variant={i === 0 ? "secondary" : "ghost"} size="sm" className={`${i===0 ? "bg-blue-50 text-blue-700 font-bold" : "text-gray-500 hover:text-gray-700"}`}>
                  {tab}
              </Button>
          ))}
      </div>

      <Card className="border-none shadow-sm bg-white overflow-hidden rounded-xl">
         {/* Filters */}
         <div className="p-4 border-b border-gray-100 flex gap-4 flex-wrap">
             <div className="relative flex-1 min-w-[250px]">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input placeholder="Search by ID, title, or description..." className="pl-9 bg-gray-50 border-gray-200" />
             </div>
             <Button variant="outline" className="gap-2 bg-white text-gray-600 border-gray-200 min-w-[120px] justify-between">
                All Priorities <Filter className="h-3 w-3 opacity-50" />
             </Button>
             <Button variant="outline" className="gap-2 bg-white text-gray-600 border-gray-200 min-w-[120px] justify-between">
                All Statuses <Filter className="h-3 w-3 opacity-50" />
             </Button>
             <Button variant="outline" className="gap-2 bg-white text-gray-600 border-gray-200 min-w-[120px] justify-between">
                All Studies <Filter className="h-3 w-3 opacity-50" />
             </Button>
             <Button variant="outline" className="gap-2 bg-white text-gray-600 border-gray-200 min-w-[120px] justify-between">
                All Types <Filter className="h-3 w-3 opacity-50" />
             </Button>
         </div>

         <CardContent className="p-0">
             <Table>
                <TableHeader className="bg-gray-50/50">
                    <TableRow className="border-gray-100">
                        <TableHead className="w-[50px] pl-6"><Checkbox /></TableHead>
                        <TableHead className="font-semibold text-gray-500">Task ID ↕</TableHead>
                        <TableHead className="font-semibold text-gray-500">Query ID ↕</TableHead>
                        <TableHead className="font-semibold text-gray-500 w-[40%]">Title ↕</TableHead>
                        <TableHead className="font-semibold text-gray-500">Priority ↕</TableHead>
                        <TableHead className="font-semibold text-gray-500 pr-6">Status ↕</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    <TableRow className="border-gray-100 hover:bg-gray-50/50">
                        <TableCell className="pl-6"><Checkbox /></TableCell>
                        <TableCell className="font-mono text-gray-600 text-xs">CRA-1759413...</TableCell>
                        <TableCell className="text-gray-400">N/A</TableCell>
                        <TableCell>
                            <div className="font-semibold text-gray-900">Document deviation, assess data impact, implement corrective action</div>
                            <div className="text-xs text-gray-500 mt-1">[CLOSED] Subject MGH-007 Visit 4 conducted 6 d...</div>
                        </TableCell>
                        <TableCell><Badge variant="secondary" className="bg-gray-100 text-gray-600 font-normal">medium</Badge></TableCell>
                        <TableCell><Badge variant="outline" className="text-green-600 border-green-200 bg-green-50 pr-6">Closed</Badge></TableCell>
                    </TableRow>
                    <TableRow className="border-gray-100 hover:bg-gray-50/50">
                        <TableCell className="pl-6"><Checkbox /></TableCell>
                        <TableCell className="font-mono text-gray-600 text-xs">CRA-1755587...</TableCell>
                        <TableCell className="text-gray-400">N/A</TableCell>
                        <TableCell>
                            <div className="font-semibold text-gray-900">Obtain IRB approval for protocol amendment v3.2</div>
                            <div className="text-xs text-gray-500 mt-1">[CLOSED] Site 1002 has not submitted IRB approv...</div>
                        </TableCell>
                        <TableCell><Badge variant="secondary" className="bg-gray-100 text-gray-600 font-normal">high</Badge></TableCell>
                        <TableCell><Badge variant="outline" className="text-green-600 border-green-200 bg-green-50 pr-6">Closed</Badge></TableCell>
                    </TableRow>
                    <TableRow className="border-gray-100 hover:bg-gray-50/50">
                        <TableCell className="pl-6"><Checkbox /></TableCell>
                        <TableCell className="font-mono text-gray-600 text-xs">QRY-8849201...</TableCell>
                        <TableCell className="text-blue-600 font-medium">QRY-1092</TableCell>
                        <TableCell>
                            <div className="font-semibold text-gray-900">Verify concomitant medication start date</div>
                            <div className="text-xs text-gray-500 mt-1">Start date is prior to informed consent date</div>
                        </TableCell>
                        <TableCell><Badge variant="secondary" className="bg-gray-100 text-gray-600 font-normal">high</Badge></TableCell>
                        <TableCell><Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50 pr-6">Open</Badge></TableCell>
                    </TableRow>
                </TableBody>
             </Table>
         </CardContent>
      </Card>
    </Layout>
  );
}
