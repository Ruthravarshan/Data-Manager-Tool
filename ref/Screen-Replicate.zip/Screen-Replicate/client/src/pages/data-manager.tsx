import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Bot, 
  Settings, 
  Play, 
  Activity, 
  CheckCircle, 
  AlertTriangle, 
  FileText, 
  Database,
  ArrowRight,
  Sparkles
} from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

export default function DataManager() {
  return (
    <Layout>
        {/* Hero Section */}
        <div className="relative overflow-hidden rounded-2xl bg-gray-900 text-white shadow-xl mb-8">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-900 to-gray-800 opacity-90"></div>
            <div className="absolute top-0 right-0 -mt-10 -mr-10 h-64 w-64 rounded-full bg-blue-600/20 blur-3xl"></div>
            
            <div className="relative z-10 flex items-center p-8 gap-6">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-emerald-500 to-green-600 shadow-lg shadow-green-900/20">
                    <Bot className="h-8 w-8 text-white" />
                </div>
                <div className="flex-1">
                    <h1 className="text-2xl font-bold tracking-tight text-white mb-1">The Quantum Analyst</h1>
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                        <span className="font-semibold text-emerald-400">Data Manager.AI</span>
                        <span>•</span>
                        <div className="flex items-center gap-1.5">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                            </span>
                            <span className="text-emerald-400">Optimizing data quality across all domains</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
                 <Button variant="ghost" className="text-blue-600 hover:text-blue-700 p-0 hover:bg-transparent text-sm font-medium">
                    &lt; Back to AI Agents Hub
                 </Button>
            </div>
        </div>

        <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Data Manager.AI</h2>
            <p className="text-gray-500">AI-powered data quality management and reconciliation</p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
            {/* Left Column: Agent Cards & Logs */}
            <div className="xl:col-span-2 space-y-8">
                {/* Agent Status Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {[
                        { title: "Data Fetch Agent", status: "Active", desc: "Listening for data refresh events", inProgress: 0, icon: Database, color: "text-emerald-500" },
                        { title: "DQ Processing", status: "Active", desc: "Running data quality checks", inProgress: 0, icon: Activity, color: "text-emerald-500" },
                        { title: "Reconciliation", status: "Active", desc: "Cross-checking data consistency", inProgress: 0, icon: CheckCircle, color: "text-emerald-500" },
                        { title: "Protocol Check", status: "Active", desc: "Verifying adherence to protocol", inProgress: 16, icon: FileText, color: "text-emerald-500" },
                    ].map((agent, i) => (
                        <Card key={i} className="border-none shadow-sm hover:shadow-md transition-shadow">
                            <CardContent className="p-5">
                                <div className="flex justify-between items-start mb-3">
                                    <div className="font-bold text-gray-800 leading-tight">{agent.title}</div>
                                    <Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-none text-[10px] px-1.5 py-0 h-5">active</Badge>
                                </div>
                                <p className="text-xs text-gray-500 mb-4 h-8">{agent.desc}</p>
                                <div className="flex justify-between items-end">
                                    <div className="text-xs text-gray-400">Records in progress:</div>
                                    <div className={`text-lg font-bold ${agent.inProgress > 0 ? "text-blue-600" : "text-gray-700"}`}>
                                        {agent.inProgress}
                                    </div>
                                </div>
                                <div className="mt-3 pt-3 border-t border-gray-100 flex justify-between text-[10px] text-gray-400">
                                    <span>Nov 28, 01:15 PM</span>
                                    <span>0 issues</span>
                                </div>
                            </CardContent>
                        </Card>
                    ))}
                </div>

                {/* Console Log */}
                <Card className="bg-slate-900 border-slate-800 text-slate-300 shadow-xl overflow-hidden">
                    <CardHeader className="py-3 px-4 bg-slate-950 border-b border-slate-800 flex flex-row items-center justify-between">
                         <div className="flex items-center gap-2">
                             <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></div>
                             <span className="text-xs font-mono font-medium text-slate-100">Agent Activity Log</span>
                             <span className="text-[10px] text-slate-500 uppercase tracking-wider">Real-time processing</span>
                         </div>
                         <div className="flex gap-1.5">
                             <div className="h-2 w-2 rounded-full bg-red-500/20"></div>
                             <div className="h-2 w-2 rounded-full bg-yellow-500/20"></div>
                             <div className="h-2 w-2 rounded-full bg-green-500/20"></div>
                         </div>
                    </CardHeader>
                    <CardContent className="p-0 font-mono text-xs">
                        <ScrollArea className="h-[250px] p-4">
                            <div className="space-y-1.5">
                                <div className="text-slate-500">[Apr 24, 2025 09:46:54] <span className="text-purple-400">SignalDetectionAgent</span>: Monitoring protocol adherence for Diabetes Type 2 Study (PRO001)</div>
                                <div className="text-slate-500">[Apr 24, 2025 09:46:54] <span className="text-purple-400">SignalDetectionAgent</span>: Monitoring protocol adherence for all trials</div>
                                <div className="text-slate-500">[Apr 30, 2025 04:47:50] <span className="text-blue-400">DataFetchAgent</span>: Fetched 1 records from integrated sources for all trials</div>
                                <div className="text-slate-500">[Apr 30, 2025 13:07:39] <span className="text-emerald-400">DataQualityAgent</span>: Analyzing data for all trials (1 records), found 1 issues</div>
                                <div className="text-slate-500">[Apr 30, 2025 13:07:39] <span className="text-pink-400">DataReconciliationAgent</span>: Cross-checking data for all trials, found 1 discrepancies</div>
                                <div className="text-slate-500">[Apr 30, 2025 13:07:42] <span className="text-orange-400">TaskManagement</span>: Created 1 tasks for data managers across all trials</div>
                            </div>
                        </ScrollArea>
                    </CardContent>
                </Card>
                
                {/* Tabs for detailed view */}
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-1 flex gap-2 overflow-x-auto">
                    {["DQ and Reconciliation", "Tasks", "Reports", "Event Monitoring", "Domain Progress", "Agent Workflow", "Settings"].map((tab, i) => (
                        <Button key={i} variant={i === 0 ? "secondary" : "ghost"} size="sm" className={cn("text-xs font-medium whitespace-nowrap", i===0 ? "bg-blue-50 text-blue-700" : "text-gray-600")}>
                            {tab}
                        </Button>
                    ))}
                </div>

                {/* Issues Table */}
                 <Card className="border-none shadow-sm bg-white overflow-hidden rounded-xl">
                    <CardContent className="p-0">
                        <Table>
                            <TableHeader className="bg-gray-50/50">
                                <TableRow className="border-gray-100">
                                    <TableHead className="w-[100px] font-semibold text-gray-500 pl-6">ID</TableHead>
                                    <TableHead className="font-semibold text-gray-500">Type</TableHead>
                                    <TableHead className="font-semibold text-gray-500">Category</TableHead>
                                    <TableHead className="font-semibold text-gray-500">Title</TableHead>
                                    <TableHead className="font-semibold text-gray-500">Status</TableHead>
                                    <TableHead className="font-semibold text-gray-500">Severity</TableHead>
                                    <TableHead className="font-semibold text-gray-500">Domain</TableHead>
                                    <TableHead className="font-semibold text-gray-500">Created</TableHead>
                                    <TableHead className="text-right font-semibold text-gray-500 pr-6">Actions</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                <TableRow className="border-gray-100 hover:bg-gray-50/50">
                                    <TableCell className="font-medium text-blue-600 pl-6">DQ-001</TableCell>
                                    <TableCell><Badge variant="outline" className="bg-blue-50 text-blue-700 border-none">Missing Data</Badge></TableCell>
                                    <TableCell><Badge variant="outline" className="bg-purple-50 text-purple-700 border-none">DQ</Badge></TableCell>
                                    <TableCell className="text-gray-800 font-medium max-w-[200px]">Missing dates in Demographics domain</TableCell>
                                    <TableCell><Badge className="bg-blue-500 hover:bg-blue-600">Detected</Badge></TableCell>
                                    <TableCell><Badge variant="outline" className="bg-rose-50 text-rose-700 border-rose-100">High</Badge></TableCell>
                                    <TableCell className="text-gray-600">DM</TableCell>
                                    <TableCell className="text-gray-600 text-xs">Apr 1, 2025</TableCell>
                                    <TableCell className="text-right pr-6"><Button variant="ghost" size="sm">View</Button></TableCell>
                                </TableRow>
                                <TableRow className="border-gray-100 hover:bg-gray-50/50">
                                    <TableCell className="font-medium text-blue-600 pl-6">DR-001</TableCell>
                                    <TableCell><Badge variant="outline" className="bg-amber-50 text-amber-700 border-none">Inconsistent Data</Badge></TableCell>
                                    <TableCell><Badge variant="outline" className="bg-blue-50 text-blue-700 border-none">Reconciliation</Badge></TableCell>
                                    <TableCell className="text-gray-800 font-medium max-w-[200px]">Lab results inconsistent with EDC data</TableCell>
                                    <TableCell><Badge className="bg-amber-500 hover:bg-amber-600">Reviewing</Badge></TableCell>
                                    <TableCell><Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-100">Medium</Badge></TableCell>
                                    <TableCell className="text-gray-600">LB, VS</TableCell>
                                    <TableCell className="text-gray-600 text-xs">Mar 28, 2025</TableCell>
                                    <TableCell className="text-right pr-6"><Button variant="ghost" size="sm">View</Button></TableCell>
                                </TableRow>
                            </TableBody>
                        </Table>
                    </CardContent>
                 </Card>
            </div>

            {/* Right Column: Chat Interface */}
            <div className="xl:col-span-1">
                <Card className="h-[calc(100vh-200px)] flex flex-col shadow-lg border-blue-100 sticky top-6">
                    <CardHeader className="bg-blue-600 text-white rounded-t-xl py-4 px-5 flex flex-row items-center justify-between">
                        <div className="flex items-center gap-2">
                             <Sparkles className="h-5 w-5 text-blue-200" />
                             <span className="font-bold">Data Manager Assistant</span>
                        </div>
                        <div className="flex gap-2">
                            <div className="h-2 w-2 bg-white/30 rounded-full"></div>
                            <div className="h-2 w-2 bg-white/30 rounded-full"></div>
                        </div>
                    </CardHeader>
                    <div className="bg-blue-50 px-4 py-3 flex gap-2 flex-wrap border-b border-blue-100">
                        {["Run DQ Checks", "Create Task", "Assign Task", "View Task", "Trial Health"].map((action, i) => (
                            <Button key={i} variant="outline" size="sm" className="bg-white border-blue-200 text-blue-700 hover:bg-blue-50 text-xs h-7">
                                {action}
                            </Button>
                        ))}
                    </div>
                    <CardContent className="flex-1 p-4 bg-gray-50/50 overflow-y-auto">
                        <div className="flex justify-start mb-4">
                            <div className="bg-white p-4 rounded-2xl rounded-tl-none shadow-sm border border-gray-100 max-w-[90%] text-sm text-gray-700 space-y-2">
                                <p className="font-medium text-gray-900 mb-2">You can ask me about:</p>
                                <ul className="list-disc pl-4 space-y-1 text-gray-600">
                                    <li>Trial health summary</li>
                                    <li>Data source health status</li>
                                    <li>Domain completeness</li>
                                    <li>What are your recommendations?</li>
                                    <li>How many DQ issues are there?</li>
                                    <li>Tell me about issue DQ-001</li>
                                </ul>
                                <p className="text-xs text-gray-400 mt-2">10:45 pm</p>
                            </div>
                        </div>
                    </CardContent>
                    <div className="p-4 bg-white border-t border-gray-100 rounded-b-xl">
                        <div className="flex items-center justify-between mb-3">
                             <span className="text-xs font-medium text-gray-500">Task Assignment Mode: <span className="text-gray-900">Agent.AI</span></span>
                             <div className="bg-blue-600 w-8 h-4 rounded-full relative cursor-pointer">
                                <div className="absolute right-0.5 top-0.5 w-3 h-3 bg-white rounded-full"></div>
                             </div>
                        </div>
                        <div className="relative">
                            <input 
                                type="text" 
                                placeholder="Ask about DQ checks, settings, monitoring..." 
                                className="w-full pl-4 pr-12 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                            <Button size="icon" className="absolute right-1.5 top-1.5 h-8 w-8 bg-blue-600 hover:bg-blue-700 rounded-lg">
                                <ArrowRight className="h-4 w-4 text-white" />
                            </Button>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    </Layout>
  );
}
