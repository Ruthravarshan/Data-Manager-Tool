import Layout from "@/components/layout";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  Signal, 
  AlertOctagon, 
  Clock, 
  Search, 
  Filter,
  Zap
} from "lucide-react";

export default function SignalDetection() {
  return (
    <Layout>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Signal Detection</h1>
          <p className="text-gray-500 mt-2">Monitor and manage risk signals across clinical trials</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-white">
            <Clock className="h-4 w-4" /> Manual Detection
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2 shadow-sm">
            <Zap className="h-4 w-4" /> Auto Detection
          </Button>
        </div>
      </div>

      <div className="mb-6">
        <div className="flex items-center gap-2 mb-4">
            <Signal className="h-5 w-5 text-blue-600" />
            <h2 className="text-lg font-bold text-gray-900">AI-Detected Signals</h2>
        </div>
        <p className="text-sm text-gray-500 mb-6">Signals automatically detected by AI analysis across clinical trial data</p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <Card className="border-none shadow-sm text-center py-2">
                <CardContent className="p-4">
                    <div className="text-4xl font-bold text-blue-600 mb-1">50</div>
                    <div className="text-sm text-gray-500 font-medium">Total Signals</div>
                </CardContent>
            </Card>
            <Card className="border-none shadow-sm text-center py-2 bg-rose-50 border border-rose-100">
                <CardContent className="p-4">
                    <div className="text-4xl font-bold text-rose-600 mb-1">7</div>
                    <div className="text-sm text-rose-700 font-medium">Critical Signals</div>
                </CardContent>
            </Card>
            <Card className="border-none shadow-sm text-center py-2 bg-amber-50 border border-amber-100">
                <CardContent className="p-4">
                    <div className="text-4xl font-bold text-amber-600 mb-1">15</div>
                    <div className="text-sm text-amber-700 font-medium">Overdue Signals</div>
                </CardContent>
            </Card>
            <Card className="border-none shadow-sm text-center py-2 bg-purple-50 border border-purple-100">
                <CardContent className="p-4">
                    <div className="text-4xl font-bold text-purple-600 mb-1">20</div>
                    <div className="text-sm text-purple-700 font-medium">Open Signals</div>
                </CardContent>
            </Card>
        </div>

        {/* Filter Bar */}
        <div className="flex gap-4 mb-6">
            <div className="relative flex-1">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
                <Input placeholder="Search signals..." className="pl-9 bg-white border-gray-200" />
            </div>
            <Button variant="outline" className="gap-2 bg-white text-gray-600 border-gray-200">
                <Filter className="h-4 w-4" /> All Priority
            </Button>
            <Button variant="outline" className="gap-2 bg-white text-gray-600 border-gray-200">
                <Filter className="h-4 w-4" /> All Status
            </Button>
            <Button variant="ghost" className="text-gray-500">Clear Filters</Button>
        </div>

        {/* Signals Table */}
        <Card className="border-none shadow-sm bg-white overflow-hidden rounded-xl">
            <CardContent className="p-0">
                <Table>
                    <TableHeader className="bg-gray-50/50">
                        <TableRow className="border-gray-100">
                            <TableHead className="w-[120px] font-semibold text-gray-500 pl-6">Signal ID</TableHead>
                            <TableHead className="font-semibold text-gray-500">Type</TableHead>
                            <TableHead className="font-semibold text-gray-500 w-[40%]">Observation</TableHead>
                            <TableHead className="font-semibold text-gray-500">Priority</TableHead>
                            <TableHead className="font-semibold text-gray-500">Study</TableHead>
                            <TableHead className="font-semibold text-gray-500">Detected ↓</TableHead>
                            <TableHead className="font-semibold text-gray-500 pr-6">Due Date</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        <TableRow className="border-gray-100 hover:bg-gray-50/50">
                            <TableCell className="font-bold text-gray-900 pl-6">SF_Risk_035</TableCell>
                            <TableCell className="text-gray-700">Safety Risk</TableCell>
                            <TableCell className="text-gray-600">Hypersensitivity reactions in 3 subjects after dose escalation...</TableCell>
                            <TableCell><Badge variant="outline" className="bg-rose-100 text-rose-700 border-none font-bold">Critical</Badge></TableCell>
                            <TableCell className="text-gray-600">PRO001</TableCell>
                            <TableCell className="text-gray-600 text-sm">Dec 8, 2025</TableCell>
                            <TableCell className="text-gray-600 text-sm pr-6">Dec 15, 2025</TableCell>
                        </TableRow>
                         <TableRow className="border-gray-100 hover:bg-gray-50/50">
                            <TableCell className="font-bold text-gray-900 pl-6">SF_Risk_034</TableCell>
                            <TableCell className="text-gray-700">Protocol Dev</TableCell>
                            <TableCell className="text-gray-600">Missed visits trend at Site 104 during winter months</TableCell>
                            <TableCell><Badge variant="outline" className="bg-amber-100 text-amber-700 border-none font-bold">High</Badge></TableCell>
                            <TableCell className="text-gray-600">PRO001</TableCell>
                            <TableCell className="text-gray-600 text-sm">Dec 7, 2025</TableCell>
                            <TableCell className="text-gray-600 text-sm pr-6">Dec 21, 2025</TableCell>
                        </TableRow>
                         <TableRow className="border-gray-100 hover:bg-gray-50/50">
                            <TableCell className="font-bold text-gray-900 pl-6">SF_Risk_033</TableCell>
                            <TableCell className="text-gray-700">Data Quality</TableCell>
                            <TableCell className="text-gray-600">Unusually high rate of query responses within 5 minutes</TableCell>
                            <TableCell><Badge variant="outline" className="bg-blue-100 text-blue-700 border-none font-bold">Medium</Badge></TableCell>
                            <TableCell className="text-gray-600">PRO002</TableCell>
                            <TableCell className="text-gray-600 text-sm">Dec 5, 2025</TableCell>
                            <TableCell className="text-gray-600 text-sm pr-6">Jan 5, 2026</TableCell>
                        </TableRow>
                    </TableBody>
                </Table>
            </CardContent>
        </Card>

      </div>
    </Layout>
  );
}
