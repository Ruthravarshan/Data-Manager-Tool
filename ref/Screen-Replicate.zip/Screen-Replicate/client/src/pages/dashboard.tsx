import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  Users, 
  AlertCircle, 
  CheckCircle2, 
  TrendingUp, 
  FileText, 
  Activity, 
  Database, 
  ShieldCheck, 
  ClipboardCheck,
  Flag
} from "lucide-react";

export default function Dashboard() {
  return (
    <Layout>
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Dashboard</h1>
          <p className="text-gray-500 mt-2">Clinical Business Orchestration and AI Technology Platform</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2">
            <FileText className="h-4 w-4" /> Reports
          </Button>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2 shadow-sm">
            <BarChart3 className="h-4 w-4" /> Analytics
          </Button>
        </div>
      </div>

      {/* Top Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[
          { label: "Active Studies", value: "4", sub: "1 new this month", icon: FlaskIcon, color: "text-blue-600", progress: 53, trend: "up" },
          { label: "Open Queries", value: "42", sub: "8 requiring attention", icon: MessageSquareIcon, color: "text-amber-600", progress: 76, trend: "down" },
          { label: "Tasks", value: "27", sub: "5 overdue tasks", icon: CheckSquareIcon, color: "text-emerald-600", progress: 68, trend: "up" },
          { label: "Signals Detected", value: "14", sub: "3 critical signals", icon: Flag, color: "text-rose-600", progress: 62, trend: "up" },
        ].map((item, i) => (
          <Card key={i} className="border-none shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <p className="text-sm font-medium text-gray-500">{item.label}</p>
                  <h3 className="text-3xl font-bold text-gray-900 mt-1">{item.value}</h3>
                </div>
                <div className={`p-2 rounded-lg bg-gray-50 ${item.color}`}>
                  <item.icon className="h-5 w-5" />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center text-xs text-gray-500 gap-2">
                  {item.trend === "up" ? (
                    <TrendingUp className="h-3 w-3 text-green-500" />
                  ) : (
                    <AlertCircle className="h-3 w-3 text-amber-500" />
                  )}
                  {item.sub}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-medium text-gray-400">Overall Progress</span>
                  <span className="text-xs font-bold text-gray-700 ml-auto">{item.progress}%</span>
                </div>
                <Progress value={item.progress} className="h-1.5" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* KPI Cards Row */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {[
          { label: "Data Quality", value: "86%", desc: "Overall data quality score", icon: Database, color: "bg-blue-50 text-blue-700" },
          { label: "Operational", value: "72%", desc: "Site operational efficiency", icon: Activity, color: "bg-indigo-50 text-indigo-700" },
          { label: "Safety", value: "91%", desc: "Protocol safety adherence", icon: ShieldCheck, color: "bg-emerald-50 text-emerald-700" },
          { label: "Compliance", value: "83%", desc: "Regulatory compliance score", icon: ClipboardCheck, color: "bg-amber-50 text-amber-700" },
        ].map((item, i) => (
          <Card key={i} className="border-none shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className={`p-2 rounded-full ${item.color}`}>
                  <CheckCircle2 className="h-4 w-4" />
                </div>
                <Badge variant="outline" className="font-normal text-xs bg-gray-50 text-gray-500 border-gray-100">
                  {item.label}
                </Badge>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-1">{item.value}</h3>
              <p className="text-xs text-gray-500 mb-3">{item.desc}</p>
              <Progress value={parseInt(item.value)} className="h-1.5" />
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Clinical Studies List */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <FlaskIcon className="h-5 w-5 text-blue-600" /> Clinical Studies
            </h2>
            <Button variant="ghost" size="sm" className="text-blue-600 hover:text-blue-700 hover:bg-blue-50">
              View All Studies
            </Button>
          </div>

          {[
            { title: "Diabetes Type 2 Study", phase: "Phase III", sites: 28, subjects: 342, progress: 76, risk: "Low Risk", riskColor: "bg-green-100 text-green-700" },
            { title: "Rheumatoid Arthritis Study", phase: "Phase II", sites: 15, subjects: 187, progress: 45, risk: "Medium Risk", riskColor: "bg-amber-100 text-amber-700" },
            { title: "Advanced Breast Cancer", phase: "Phase III", sites: 32, subjects: 274, progress: 28, risk: "High Risk", riskColor: "bg-rose-100 text-rose-700" },
          ].map((study, i) => (
            <Card key={i} className="border-none shadow-sm hover:shadow-md transition-shadow overflow-hidden">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-lg font-bold text-gray-900">{study.title}</h3>
                  <Badge className={`font-medium border-none shadow-none ${study.riskColor}`}>{study.risk}</Badge>
                </div>
                <p className="text-sm text-gray-500 mb-4 line-clamp-1">Investigating efficacy of treatment in controlled groups...</p>
                
                <div className="flex items-center gap-4 text-xs text-gray-500 mb-4">
                  <span className="font-medium text-gray-700">{study.phase}</span>
                  <span>•</span>
                  <span>{study.sites} sites</span>
                  <span>•</span>
                  <span>{study.subjects} subjects</span>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="font-medium text-gray-600">Progress</span>
                    <span className="font-bold text-gray-900">{study.progress}%</span>
                  </div>
                  <Progress value={study.progress} className="h-2" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Right Column - Protocol Deviations & Alerts */}
        <div className="space-y-6">
          <div className="flex items-center justify-between">
             <h2 className="text-lg font-bold text-gray-900 flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-blue-600" /> Protocol Deviations
            </h2>
          </div>
          
          {[
             { code: "PD-101: Eligibility", severity: "Minor", desc: "Subject enrolled outside inclusion criteria #4", site: "Site: Boston Medical", color: "text-amber-600", bg: "bg-amber-50" },
             { code: "PD-102: Treatment", severity: "Major", desc: "Missed dose on day 14 ±2", site: "Site: NYC Research", color: "text-rose-600", bg: "bg-rose-50" },
             { code: "PD-103: Procedure", severity: "Minor", desc: "Blood sample collected outside window", site: "Site: Chicago Clinical", color: "text-amber-600", bg: "bg-amber-50" },
          ].map((dev, i) => (
            <Card key={i} className="border-none shadow-sm">
              <CardContent className="p-5">
                <div className="flex justify-between items-start mb-2">
                  <span className="font-bold text-sm text-gray-900">{dev.code}</span>
                  <Badge variant="outline" className={`text-xs ${dev.bg} ${dev.color} border-none`}>{dev.severity}</Badge>
                </div>
                <p className="text-xs text-gray-600 mb-2">{dev.desc}</p>
                <p className="text-xs text-gray-400">{dev.site}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}

// Icons placeholders
function FlaskIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M8.5 2h7"/><path d="M12 2v6.5"/><path d="m5 16 7-6.5L19 16"/><path d="M5 16v6h14v-6"/><path d="M10 22v-6"/></svg> }
function MessageSquareIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg> }
function CheckSquareIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 11 3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg> }
