import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  ShieldCheck, 
  Activity, 
  FileCheck, 
  AlertTriangle, 
  Eye, 
  Search,
  Users,
  Database
} from "lucide-react";
import { cn } from "@/lib/utils";

export default function CentralMonitor() {
  return (
    <Layout>
         {/* Hero Section */}
         <div className="relative overflow-hidden rounded-2xl bg-gray-900 text-white shadow-xl mb-8">
             <div className="absolute inset-0 bg-gradient-to-r from-gray-900 to-gray-800 opacity-95"></div>
             {/* Abstract red glow */}
             <div className="absolute top-0 left-0 -mt-10 -ml-10 h-64 w-64 rounded-full bg-rose-600/20 blur-3xl"></div>
            
            <div className="relative z-10 flex items-center p-8 gap-6">
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-rose-500 to-red-600 shadow-lg shadow-rose-900/20">
                    <ShieldCheck className="h-8 w-8 text-white" />
                </div>
                <div className="flex-1">
                    <h1 className="text-2xl font-bold tracking-tight text-white mb-1">The Sentinel Guardian</h1>
                    <div className="flex items-center gap-2 text-gray-400 text-sm">
                        <span className="font-semibold text-rose-400">Central Monitor.AI</span>
                        <span>•</span>
                        <div className="flex items-center gap-1.5">
                            <span className="relative flex h-2 w-2">
                              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                              <span className="relative inline-flex rounded-full h-2 w-2 bg-rose-500"></span>
                            </span>
                            <span className="text-rose-400">Vigilance activated across all trial data</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div className="mb-6 flex items-center justify-between">
            <div className="flex items-center gap-4">
                 <Button variant="ghost" className="text-blue-600 hover:text-blue-700 p-0 hover:bg-transparent text-sm font-medium">
                    &lt; Back to AI Agents Hub
                 </Button>
            </div>
        </div>

        <div className="mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Central Monitor.AI</h2>
            <p className="text-gray-500">AI-powered monitoring for clinical trial data</p>
        </div>

        {/* AI Monitoring Agents Cards */}
        <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-800">AI Monitoring Agents</h3>
                <Button variant="ghost" size="sm" className="text-blue-600">Expand</Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                    { title: "Protocol Monitor", status: "Active", desc: "Monitoring protocol deviations", stat: "3 deviations detected", sub: "2 queries", color: "bg-emerald-50 text-emerald-700" },
                    { title: "Site Performance", status: "Active", desc: "Tracking site metrics", stat: "12 sites monitored", sub: "1 alert", color: "bg-emerald-50 text-emerald-700" },
                    { title: "Lab Data Monitor", status: "Active", desc: "Analyzing lab trends", stat: "287 values analyzed", sub: "8 abnormal", color: "bg-emerald-50 text-emerald-700" },
                    { title: "Safety Signal", status: "Active", desc: "Detecting safety signals", stat: "42 AEs analyzed", sub: "3 signals", color: "bg-emerald-50 text-emerald-700" },
                ].map((agent, i) => (
                    <Card key={i} className="border-none shadow-sm hover:shadow-md transition-shadow">
                        <CardContent className="p-5">
                            <div className="flex justify-between items-start mb-2">
                                <div className="flex items-center gap-2">
                                    <div className={`h-2 w-2 rounded-full ${agent.status === "Active" ? "bg-emerald-500" : "bg-gray-300"}`}></div>
                                    <span className="font-bold text-gray-800 text-sm">{agent.title}</span>
                                </div>
                                <Badge variant="secondary" className="bg-emerald-50 text-emerald-700 text-[10px] h-5">Active</Badge>
                            </div>
                            <p className="text-xs text-gray-500 mb-4">{agent.desc}</p>
                            <div className="flex justify-between items-end border-t border-gray-50 pt-3">
                                <span className="text-xs text-gray-600 font-medium">{agent.stat}</span>
                                <span className="text-xs font-bold text-blue-600">{agent.sub}</span>
                            </div>
                        </CardContent>
                    </Card>
                ))}
            </div>
        </div>

        {/* Dashboard Tabs */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-1 flex gap-2 overflow-x-auto mb-6">
            {["Dashboard", "Queries", "Tasks", "Event Log", "Workflows", "Settings"].map((tab, i) => (
                <Button key={i} variant={i === 0 ? "secondary" : "ghost"} size="sm" className={cn("text-xs font-medium whitespace-nowrap px-6", i===0 ? "bg-white shadow-sm text-gray-900 font-bold" : "text-gray-500")}>
                    {tab}
                </Button>
            ))}
        </div>

        {/* DB Lock Compliance Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
            <Card className="border-none shadow-sm lg:col-span-1">
                 <CardContent className="p-6">
                     <div className="flex items-center gap-2 mb-4 text-gray-500 text-sm font-medium">
                         <Database className="h-4 w-4" /> DB Lock Compliance
                     </div>
                     <div className="text-sm text-gray-500 mb-1">Status</div>
                     <div className="text-2xl font-bold text-blue-700 mb-4">IN PROGRESS</div>
                     <div className="text-xs text-gray-400">Est. Lock Date: 8/1/2026</div>
                 </CardContent>
            </Card>

            <Card className="border-none shadow-sm lg:col-span-1">
                 <CardContent className="p-6">
                     <div className="text-sm text-gray-500 mb-1">Overall Readiness</div>
                     <div className="text-3xl font-bold text-blue-600 mb-4">75%</div>
                     <Progress value={75} className="h-2 bg-blue-100" />
                 </CardContent>
            </Card>

            <Card className="border-none shadow-sm lg:col-span-1">
                 <CardContent className="p-6">
                     <div className="text-sm text-gray-500 mb-1">Outstanding Issues</div>
                     <div className="text-3xl font-bold text-amber-500 mb-1">8</div>
                     <div className="text-xs text-gray-400">Across 3 sites</div>
                 </CardContent>
            </Card>

            <Card className="border-none shadow-sm lg:col-span-1">
                 <CardContent className="p-6">
                     <div className="text-sm text-gray-500 mb-3">Site Readiness</div>
                     <div className="space-y-2">
                         <div className="flex justify-between text-xs">
                             <span className="text-gray-500">Complete</span>
                             <span className="font-medium text-gray-900">0/3</span>
                         </div>
                         <div className="flex justify-between text-xs">
                             <span className="text-gray-500">Ready</span>
                             <span className="font-medium text-gray-900">1/3</span>
                         </div>
                         <div className="flex justify-between text-xs">
                             <span className="text-gray-500">In Progress</span>
                             <span className="font-medium text-gray-900">2/3</span>
                         </div>
                     </div>
                 </CardContent>
            </Card>
        </div>

        {/* Site-Level Compliance Table */}
        <Card className="border-none shadow-sm bg-white overflow-hidden rounded-xl mb-8">
            <CardHeader className="bg-white px-6 py-4 border-b border-gray-100">
                <CardTitle className="text-lg font-bold text-gray-800">Site-Level DB Lock Compliance</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
                <Table>
                    <TableHeader className="bg-gray-50/50">
                        <TableRow className="border-gray-100">
                            <TableHead className="font-semibold text-gray-500 pl-6">Site</TableHead>
                            <TableHead className="font-semibold text-gray-500">Status</TableHead>
                            <TableHead className="font-semibold text-gray-500">Readiness</TableHead>
                            <TableHead className="font-semibold text-gray-500">Outstanding Issues</TableHead>
                            <TableHead className="text-right font-semibold text-gray-500 pr-6">Last Updated</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        <TableRow className="border-gray-100 hover:bg-gray-50/50">
                            <TableCell className="font-medium text-gray-900 pl-6">Boston Medical Center</TableCell>
                            <TableCell><Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-none">IN PROGRESS</Badge></TableCell>
                            <TableCell className="w-[200px]">
                                <div className="flex items-center gap-2">
                                    <span className="text-xs font-medium w-8">78%</span>
                                    <Progress value={78} className="h-2 flex-1" />
                                </div>
                            </TableCell>
                            <TableCell className="text-gray-700">4</TableCell>
                            <TableCell className="text-right pr-6 text-gray-500">7/12/2025</TableCell>
                        </TableRow>
                         <TableRow className="border-gray-100 hover:bg-gray-50/50">
                            <TableCell className="font-medium text-gray-900 pl-6">Chicago Research Hospital</TableCell>
                            <TableCell><Badge className="bg-emerald-100 text-emerald-700 hover:bg-emerald-100 border-none">READY</Badge></TableCell>
                            <TableCell className="w-[200px]">
                                <div className="flex items-center gap-2">
                                    <span className="text-xs font-medium w-8">92%</span>
                                    <Progress value={92} className="h-2 flex-1" />
                                </div>
                            </TableCell>
                            <TableCell className="text-gray-700">0</TableCell>
                            <TableCell className="text-right pr-6 text-gray-500">8/12/2025</TableCell>
                        </TableRow>
                         <TableRow className="border-gray-100 hover:bg-gray-50/50">
                            <TableCell className="font-medium text-gray-900 pl-6">Denver Health Institute</TableCell>
                            <TableCell><Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-none">IN PROGRESS</Badge></TableCell>
                            <TableCell className="w-[200px]">
                                <div className="flex items-center gap-2">
                                    <span className="text-xs font-medium w-8">67%</span>
                                    <Progress value={67} className="h-2 flex-1" />
                                </div>
                            </TableCell>
                            <TableCell className="text-gray-700">8</TableCell>
                            <TableCell className="text-right pr-6 text-gray-500">6/12/2025</TableCell>
                        </TableRow>
                    </TableBody>
                </Table>
            </CardContent>
        </Card>
    </Layout>
  );
}
