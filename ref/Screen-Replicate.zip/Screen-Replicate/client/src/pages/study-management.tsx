import Layout from "@/components/layout";
import { CreateStudyModal } from "@/components/create-study-modal";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface Study {
  id: string;
  protocolId: string;
  title: string;
  therapeuticArea: string;
  indication: string;
  phase: string;
  status: "Active" | "Planned" | "Completed";
}

const initialStudies: Study[] = [
  {
    id: "1",
    protocolId: "PRO001",
    title: "Diabetes Type 2 Study",
    therapeuticArea: "Metabolism",
    indication: "Type 2 Diabetes",
    phase: "Phase 3",
    status: "Active",
  },
  {
    id: "2",
    protocolId: "PRO002",
    title: "Oncology Combination Therapy",
    therapeuticArea: "Oncology",
    indication: "NSCLC",
    phase: "Phase 2",
    status: "Active",
  },
  {
    id: "3",
    protocolId: "PRO003",
    title: "Cardiovascular Outcomes Study",
    therapeuticArea: "Cardiovascular",
    indication: "Heart Failure",
    phase: "Phase 4",
    status: "Active",
  },
];

export default function StudyManagement() {
  const [studies, setStudies] = useState<Study[]>(initialStudies);
  const { toast } = useToast();

  const handleCreateStudy = (data: any) => {
    const newStudy: Study = {
      id: Math.random().toString(36).substr(2, 9),
      protocolId: `PRO00${studies.length + 1}`,
      title: data.title,
      therapeuticArea: data.therapeuticArea,
      indication: data.indication,
      phase: "Phase 1", // Default for new
      status: data.status,
    };
    setStudies([...studies, newStudy]);
    toast({
      title: "Success",
      description: "New study created successfully.",
    });
  };

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Study Management</h1>
      </div>

      <Card className="border-none shadow-sm bg-white overflow-hidden rounded-xl">
        <CardHeader className="flex flex-row items-center justify-between border-b border-gray-100 bg-white px-6 py-5">
          <CardTitle className="text-xl font-bold text-gray-800">All Studies</CardTitle>
          <CreateStudyModal onStudyCreate={handleCreateStudy} />
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-gray-50/50">
              <TableRow className="border-gray-100 hover:bg-transparent">
                <TableHead className="w-[100px] font-semibold text-gray-500 pl-6">Protocol ID</TableHead>
                <TableHead className="font-semibold text-gray-500">Title</TableHead>
                <TableHead className="font-semibold text-gray-500">Therapeutic Area</TableHead>
                <TableHead className="font-semibold text-gray-500">Indication</TableHead>
                <TableHead className="font-semibold text-gray-500">Phase</TableHead>
                <TableHead className="font-semibold text-gray-500">Status</TableHead>
                <TableHead className="text-right font-semibold text-gray-500 pr-6">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {studies.map((study) => (
                <TableRow key={study.id} className="border-gray-100 hover:bg-gray-50/50 transition-colors">
                  <TableCell className="font-medium text-gray-900 pl-6">{study.protocolId}</TableCell>
                  <TableCell className="text-gray-700 font-medium">{study.title}</TableCell>
                  <TableCell className="text-gray-600">{study.therapeuticArea}</TableCell>
                  <TableCell className="text-gray-600">{study.indication}</TableCell>
                  <TableCell className="text-gray-600">{study.phase}</TableCell>
                  <TableCell>
                    <Badge 
                      variant="secondary" 
                      className={cn(
                        "font-medium",
                        study.status === "Active" && "bg-green-100 text-green-700 hover:bg-green-100",
                        study.status === "Planned" && "bg-blue-100 text-blue-700 hover:bg-blue-100",
                        study.status === "Completed" && "bg-gray-100 text-gray-700 hover:bg-gray-100"
                      )}
                    >
                      {study.status}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right pr-6">
                    <Button variant="outline" size="sm" className="h-8 px-4 font-medium text-gray-700 border-gray-200 hover:bg-gray-50 hover:text-gray-900">
                      View
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </Layout>
  );
}
