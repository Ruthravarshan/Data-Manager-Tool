import Layout from "@/components/layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Plus, 
  RefreshCw, 
  Pause, 
  MoreHorizontal, 
  Database, 
  Calendar, 
  Activity,
  Download
} from "lucide-react";

export default function DataIntegration() {
  const integrations = [
    { name: "EDC Data Feed", vendor: "Medidata Rave", type: "API", freq: "Daily at 2:00 AM", lastSync: "2023-04-04 02:00:15", status: "Active" },
    { name: "Central Lab Results", vendor: "Labcorp", type: "SFTP", freq: "Every 12 hours", lastSync: "2023-04-04 14:00:03", status: "Active" },
    { name: "Imaging Data", vendor: "Calyx", type: "S3", freq: "Weekly on Monday", lastSync: "2023-04-01 08:30:22", status: "Inactive" },
    { name: "ECG Data", vendor: "AliveCor", type: "API", freq: "Daily at 4:00 AM", lastSync: "2023-04-04 04:12:55", status: "Active" },
    { name: "CTMS Data", vendor: "Veeva Vault CTMS", type: "API", freq: "Daily at 6:00 AM", lastSync: "2023-04-04 06:00:05", status: "Error", errorMsg: "API authentication failed. Check credentials." },
    { name: "eCOA Data", vendor: "ClinicalInk", type: "API", freq: "Every 6 hours", lastSync: "2023-04-04 18:00:22", status: "Configuring..." },
  ];

  return (
    <Layout>
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 tracking-tight">Data Integration</h1>
        <p className="text-gray-500 mt-2">Manage data integrations and connections across your clinical trials</p>
      </div>

      <div className="mb-6">
        <Tabs defaultValue="sources" className="w-full">
          <TabsList className="bg-white border p-1 rounded-lg">
            <TabsTrigger value="sources" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 gap-2">
              <Database className="h-4 w-4" /> Data Sources
            </TabsTrigger>
            <TabsTrigger value="scheduler" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 gap-2">
              <Calendar className="h-4 w-4" /> Scheduler
            </TabsTrigger>
            <TabsTrigger value="monitoring" className="data-[state=active]:bg-blue-50 data-[state=active]:text-blue-700 gap-2">
              <Activity className="h-4 w-4" /> Real-Time Monitoring
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <Card className="border-none shadow-sm bg-white overflow-hidden rounded-xl">
        <CardHeader className="flex flex-row items-center justify-between border-b border-gray-100 bg-white px-6 py-5">
          <div>
            <CardTitle className="text-xl font-bold text-gray-800 flex items-center gap-2">
              <Database className="h-5 w-5 text-blue-600" /> Data Source Manager
            </CardTitle>
            <p className="text-sm text-gray-500 mt-1">Configure and manage data integrations from external sources</p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white gap-2 shadow-sm">
            <Plus className="h-4 w-4" /> Add Integration
          </Button>
        </CardHeader>
        
        <div className="px-6 py-4 bg-gray-50/50 border-b border-gray-100 flex items-center justify-between">
          <div className="flex gap-4">
             {/* Simple Filters Placeholder */}
             <Button variant="outline" size="sm" className="bg-white text-gray-600 border-gray-200">All Types</Button>
             <Button variant="outline" size="sm" className="bg-white text-gray-600 border-gray-200">All Statuses</Button>
          </div>
          <div className="bg-rose-50 border border-rose-100 text-rose-700 px-4 py-2 rounded-md text-sm flex items-center gap-2">
            <AlertIcon className="h-4 w-4" />
            One or more integrations have errors. Please check the integration details.
          </div>
          <Button variant="ghost" size="sm" className="text-gray-600 gap-2">
            <Download className="h-4 w-4" /> Export Configuration
          </Button>
        </div>

        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-gray-50/50">
              <TableRow className="border-gray-100">
                <TableHead className="w-[150px] font-semibold text-gray-500 pl-6">Name</TableHead>
                <TableHead className="font-semibold text-gray-500">Vendor</TableHead>
                <TableHead className="font-semibold text-gray-500">Type</TableHead>
                <TableHead className="font-semibold text-gray-500">Frequency</TableHead>
                <TableHead className="font-semibold text-gray-500">Last Sync</TableHead>
                <TableHead className="font-semibold text-gray-500">Status</TableHead>
                <TableHead className="text-right font-semibold text-gray-500 pr-6">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {integrations.map((item, i) => (
                <TableRow key={i} className="border-gray-100 hover:bg-gray-50/50">
                  <TableCell className="font-medium text-blue-600 pl-6">
                    {item.name}
                  </TableCell>
                  <TableCell className="text-gray-900 font-medium">{item.vendor}</TableCell>
                  <TableCell>
                    <Badge variant="secondary" className={`font-medium ${
                        item.type === "API" ? "bg-purple-100 text-purple-700" : 
                        item.type === "SFTP" ? "bg-amber-100 text-amber-700" :
                        "bg-green-100 text-green-700"
                    }`}>
                      {item.type}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-gray-600">{item.freq}</TableCell>
                  <TableCell className="text-gray-600 font-mono text-xs">{item.lastSync}</TableCell>
                  <TableCell>
                     {item.status === "Error" ? (
                        <div className="flex flex-col">
                            <Badge variant="destructive" className="w-fit bg-rose-100 text-rose-700 hover:bg-rose-100 border-none shadow-none">Error</Badge>
                            <span className="text-[10px] text-rose-600 mt-1 max-w-[150px] leading-tight">{item.errorMsg}</span>
                        </div>
                     ) : item.status === "Configuring..." ? (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-700 hover:bg-blue-100">{item.status}</Badge>
                     ) : item.status === "Inactive" ? (
                        <Badge variant="secondary" className="bg-gray-100 text-gray-500 hover:bg-gray-100">{item.status}</Badge>
                     ) : (
                        <Badge variant="secondary" className="bg-green-100 text-green-700 hover:bg-green-100">{item.status}</Badge>
                     )}
                  </TableCell>
                  <TableCell className="text-right pr-6">
                    <div className="flex items-center justify-end gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-blue-600">
                        <RefreshCw className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-gray-600">
                        <Pause className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-gray-600">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </Layout>
  );
}

function AlertIcon(props: any) { return <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg> }
