import { useState } from "react";
import { Link, useLocation } from "wouter";
import { 
  LayoutGrid, 
  FlaskConical, 
  Network, 
  FileText, 
  Code, 
  Monitor, 
  Radio, 
  CheckCircle, 
  Bot, 
  ChevronDown,
  Menu
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface LayoutProps {
  children: React.ReactNode;
}

const navItems = [
  { label: "AI Agents", icon: Bot, href: "/ai-agents", badge: "AI HUB" },
  { label: "Dashboard", icon: LayoutGrid, href: "/dashboard" },
  { label: "Study Management", icon: FlaskConical, href: "/" },
  { label: "Data Integration", icon: Network, href: "/data-integration" },
  { label: "Trial Data Management", icon: FileText, href: "/trial-data" },
  { label: "Data Manager.AI", icon: Code, href: "/data-manager" },
  { label: "Central Monitor.AI", icon: Monitor, href: "/central-monitor" },
  { label: "Signal Detection", icon: Radio, href: "/signal-detection" },
  { label: "Tasks Management", icon: CheckCircle, href: "/tasks" },
];

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);

  const Sidebar = () => (
    <div className="flex h-full flex-col bg-sidebar text-sidebar-foreground">
      <div className="flex h-16 items-center px-6">
        {/* Logo area if needed, but screenshot just shows menu items starting high or below a header */}
      </div>
      <nav className="flex-1 space-y-1 px-3 py-4">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <a
                className={cn(
                  "group flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors",
                  isActive
                    ? "bg-white text-blue-700 shadow-sm"
                    : "text-blue-100 hover:bg-blue-700/50 hover:text-white"
                )}
              >
                <item.icon
                  className={cn(
                    "mr-3 h-5 w-5 flex-shrink-0",
                    isActive ? "text-blue-700" : "text-blue-200 group-hover:text-white"
                  )}
                />
                <span className="flex-1">{item.label}</span>
                {item.badge && (
                  <span className="ml-auto inline-flex items-center rounded-full bg-gradient-to-r from-purple-500 to-pink-500 px-2 py-0.5 text-xs font-medium text-white shadow-sm">
                    {item.badge}
                  </span>
                )}
              </a>
            </Link>
          );
        })}
      </nav>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Top Banner */}
      <div className="bg-blue-700 text-white text-center py-2 text-sm font-semibold tracking-wide z-20 shadow-md">
        Clinical Business Orchestration and AI Technology Platform
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Desktop Sidebar */}
        <aside className="hidden w-72 flex-col bg-blue-600 md:flex border-r border-blue-500/30 shadow-xl z-10">
           <Sidebar />
        </aside>

        {/* Mobile Sidebar */}
        <div className="md:hidden">
            <Sheet open={isMobileOpen} onOpenChange={setIsMobileOpen}>
                <SheetTrigger asChild>
                    <Button variant="ghost" size="icon" className="fixed left-4 top-10 z-40 text-white">
                        <Menu className="h-6 w-6" />
                    </Button>
                </SheetTrigger>
                <SheetContent side="left" className="p-0 w-72 border-r-0">
                    <Sidebar />
                </SheetContent>
            </Sheet>
        </div>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto bg-gray-50/50">
          {/* Header with User Profile */}
          <header className="flex h-16 items-center justify-end bg-white px-8 shadow-sm border-b border-gray-100">
            <div className="flex items-center gap-3 cursor-pointer hover:bg-gray-50 p-2 rounded-lg transition-colors">
              <Avatar className="h-9 w-9 bg-blue-100 text-blue-700 border border-blue-200">
                <AvatarFallback>SA</AvatarFallback>
              </Avatar>
              <div className="text-right hidden sm:block">
                <p className="text-sm font-semibold text-gray-900 leading-none">System Administrator</p>
                <p className="text-xs text-gray-500 mt-1">System Administrator</p>
              </div>
              <ChevronDown className="h-4 w-4 text-gray-400" />
            </div>
          </header>

          <div className="p-8 max-w-7xl mx-auto">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
